package com.homemusclebuilder.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private var level = 0
    private var seconds = 0
    private var timerOn = false
    private var completed = mutableSetOf<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timerText: TextView
    private lateinit var progressText: TextView
    private lateinit var list: LinearLayout
    private val levels = arrayOf("Beginner", "Intermediate", "Advanced")
    private val workouts = arrayOf(
        arrayOf("Push-ups|3 sets × 8 reps", "Knee push-ups|2 sets × 8 reps", "Wide push-ups|2 sets × 6 reps", "Pike push-ups|2 sets × 5 reps", "Superman raises|2 sets × 10 reps", "Plank|2 sets × 20 sec"),
        arrayOf("Push-ups|4 sets × 12 reps", "Diamond push-ups|3 sets × 8 reps", "Wide push-ups|3 sets × 12 reps", "Pike push-ups|3 sets × 10 reps", "Superman raises|3 sets × 15 reps", "Plank|3 sets × 45 sec"),
        arrayOf("Decline push-ups|4 sets × 15 reps", "Diamond push-ups|4 sets × 12 reps", "Archer push-ups|3 sets × 8 each side", "Pike push-ups|4 sets × 12 reps", "Superman raises|4 sets × 20 reps", "Plank|3 sets × 60 sec")
    )
    private val tick = object : Runnable {
        override fun run() {
            if (timerOn) {
                seconds++
                timerText.text = String.format("%02d:%02d", seconds / 60, seconds % 60)
                handler.postDelayed(this, 1000)
            }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.rgb(30, 35, 45))
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
    }
    private fun button(s: String, action: () -> Unit): Button {
        return Button(this).apply { text = s; setOnClickListener { action() } }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); setBackgroundColor(Color.rgb(245,247,250)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cover = ImageView(this).apply {
            setImageResource(R.drawable.app_cover)
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = true
            contentDescription = "Home Muscle Builder cover: muscular athlete doing push-ups"
        }
        content.addView(cover, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)))
        content.addView(text("HOME MUSCLE BUILDER 💪", 25f, true))
        content.addView(text("No equipment • Train at home • Build strength", 14f))
        content.addView(text("Choose your level", 18f, true))
        val levelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        levels.forEachIndexed { i, name -> levelRow.addView(button(name) { level = i; completed.clear(); renderExercises() }, LinearLayout.LayoutParams(0, dp(55), 1f)) }
        content.addView(levelRow)
        content.addView(text("TODAY'S WORKOUT • CHEST & ARMS", 18f, true))
        content.addView(text("Warm up for 5 minutes first. Use controlled movements and stop if you feel pain.", 14f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(text("SESSION TIMER", 18f, true))
        timerText = text("00:00", 30f, true)
        content.addView(timerText)
        val timerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timerRow.addView(button("Start / Resume") { if (!timerOn) { timerOn = true; handler.post(tick) } })
        timerRow.addView(button("Pause") { timerOn = false })
        timerRow.addView(button("Reset") { timerOn = false; seconds = 0; timerText.text = "00:00" })
        content.addView(timerRow)
        progressText = text("0 / 6 exercises complete", 16f, true)
        content.addView(progressText)
        content.addView(text("WEEKLY PLAN", 18f, true))
        content.addView(text("MON Chest & Arms  •  TUE Legs & Abs\nWED Recovery  •  THU Shoulders & Core\nFRI Full Body  •  SAT Recovery / Walk\nSUN Rest", 14f))
        content.addView(text("Progress gradually. Rest between sets. Muscle growth also needs enough food, protein, and sleep.", 14f))
        scroll.addView(content); page.addView(scroll); setContentView(page)
        renderExercises()
    }
    private fun renderExercises() {
        list.removeAllViews()
        workouts[level].forEachIndexed { i, item ->
            val parts = item.split("|")
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val label = TextView(this).apply { text = "${i+1}. ${parts[0]}\n${parts[1]}"; textSize = 15f; setTextColor(Color.DKGRAY); setPadding(dp(8),dp(10),dp(4),dp(10)) }
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button(if (completed.contains(i)) "✓ Done" else "Complete") {
                if (completed.contains(i)) completed.remove(i) else completed.add(i)
                renderExercises()
            })
            list.addView(row)
            val divider = TextView(this).apply { setBackgroundColor(Color.LTGRAY); height = dp(1) }
            list.addView(divider)
        }
        progressText.text = "${completed.size} / 6 exercises complete"
    }
}
