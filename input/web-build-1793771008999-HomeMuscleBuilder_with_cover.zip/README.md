# Home Muscle Builder (Android source project)

A basic native Android app for bodyweight muscle-building workouts. Includes three levels, a selectable exercise checklist, session timer, and weekly schedule.

## Build
This is Android source code, not a prebuilt APK.
- Open this folder in Android Studio (or import it into a compatible Android build service).
- Build the APK using Gradle: `gradle assembleDebug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

Project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, minimum Android 6.0 (API 23).

## Workout safety
Warm up first, use good form, and stop if you experience pain. Increase difficulty gradually. Recovery is part of training.
