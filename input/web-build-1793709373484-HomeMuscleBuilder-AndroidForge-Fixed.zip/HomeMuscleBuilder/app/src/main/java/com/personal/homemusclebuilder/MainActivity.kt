package com.personal.homemusclebuilder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class WorkoutDay(val day: String, val focus: String, val moves: List<String>, val recovery: Boolean = false)

private val plan = listOf(
    WorkoutDay("Monday", "Chest & Triceps", listOf("Push-ups — 3 × 8–12", "Wide push-ups — 3 × 8–12", "Knee diamond push-ups — 2 × 6–10", "Plank — 3 × 30 sec")),
    WorkoutDay("Tuesday", "Legs & Glutes", listOf("Bodyweight squats — 3 × 12–15", "Reverse lunges — 3 × 10 each leg", "Glute bridges — 3 × 15", "Calf raises — 3 × 20", "Wall sit — 3 × 30 sec")),
    WorkoutDay("Wednesday", "Back & Biceps", listOf("Superman raises — 3 × 12", "Reverse snow angels — 3 × 10", "Prone Y-T raises — 2 × 8 each", "Self-resisted biceps curls — 3 × 12 each arm", "Bird-dogs — 3 × 10 each side")),
    WorkoutDay("Thursday", "Shoulders & Abs", listOf("Pike push-ups — 3 × 6–10", "Shoulder taps — 3 × 20 taps", "Crunches — 3 × 15", "Lying leg raises — 3 × 10", "Side plank — 2 × 20 sec each side")),
    WorkoutDay("Friday", "Full Body", listOf("Push-ups — 3 × 8–12", "Squats — 3 × 15", "Reverse lunges — 3 × 10 each leg", "Mountain climbers — 3 × 30 sec", "Plank — 3 × 40 sec")),
    WorkoutDay("Saturday & Sunday", "Rest & Recovery", listOf("Gentle walking", "Light stretching", "Sleep and recover"), true)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeMuscleBuilderApp() }
    }
}

@Composable
fun HomeMuscleBuilderApp() {
    var selectedDay by remember { mutableStateOf("Monday") }
    var checkedMoves by remember { mutableStateOf(setOf<String>()) }
    var restSeconds by remember { mutableIntStateOf(60) }
    val day = plan.first { it.day == selectedDay }
    val completed = day.moves.count { checkedMoves.contains("$selectedDay:$it") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B45), secondary = Color(0xFF7BC69A))) {
        Scaffold(containerColor = Color(0xFFF4F7F5)) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp)
            ) {
                item {
                    Text("HOME MUSCLE BUILDER", fontSize = 13.sp, color = Color(0xFF176B45), fontWeight = FontWeight.Bold)
                    Text("Your body. Your strength.", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("No equipment • Monday to Friday • At home", color = Color.DarkGray)
                }
                item {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE2F2E8))) {
                        Column(Modifier.padding(16.dp)) {
                            Text("WEEKLY PLAN", fontWeight = FontWeight.Bold, color = Color(0xFF176B45))
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf("Mon", "Tue", "Wed", "Thu", "Fri").forEachIndexed { index, short ->
                                    val full = plan[index].day
                                    Button(onClick = { selectedDay = full }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedDay == full) Color(0xFF176B45) else Color.White, contentColor = if (selectedDay == full) Color.White else Color(0xFF176B45))) {
                                        Text(short, fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { selectedDay = "Saturday & Sunday" }, modifier = Modifier.weight(1f)) { Text("Weekend recovery") }
                            }
                        }
                    }
                }
                item {
                    Text(day.day, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(day.focus, fontSize = 18.sp, color = Color(0xFF176B45), fontWeight = FontWeight.SemiBold)
                    Text(if (day.recovery) "Recovery day — let your muscles rest." else "Warm up for 5 minutes. Aim for controlled reps and good form.", color = Color.DarkGray)
                    if (!day.recovery) Text("Progress: $completed / ${day.moves.size} exercises completed", fontWeight = FontWeight.Bold)
                }
                items(day.moves) { move ->
                    val key = "$selectedDay:$move"
                    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = checkedMoves.contains(key), onCheckedChange = { checked ->
                                checkedMoves = if (checked) checkedMoves + key else checkedMoves - key
                            })
                            Text(move, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE2F2E8))) {
                        Column(Modifier.padding(16.dp)) {
                            Text("REST TIMER", fontWeight = FontWeight.Bold, color = Color(0xFF176B45))
                            Text("$restSeconds seconds between sets", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { restSeconds = 45 }) { Text("45 sec") }
                                OutlinedButton(onClick = { restSeconds = 60 }) { Text("60 sec") }
                                OutlinedButton(onClick = { restSeconds = 90 }) { Text("90 sec") }
                            }
                            Text("Timer setting only; use your phone's clock to count down.", fontSize = 12.sp, color = Color.DarkGray)
                        }
                    }
                }
                item {
                    Text("Muscle-building tip: when every set feels manageable, gradually add reps or choose a harder variation. Stop if you feel sharp pain.", fontSize = 13.sp, color = Color.DarkGray)
                }
            }
        }
    }
}
